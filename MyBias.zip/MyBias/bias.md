Minji (Kim Minji)

Minji, born on May 7, 2004, in Chuncheon, Gangwon, South Korea, is often seen as the de facto leader of NewJeans. She has a calm and responsible demeanor, enjoys reading mystery novels, and has a penchant for cleanliness and organization. If Minji is your bias, you might value leadership, responsibility, and have a detail-oriented nature. You likely appreciate a composed and thoughtful approach to challenges and may have a strong sense of duty.

Hanni (Hanni Pham)

Hanni, born on October 6, 2004, in Melbourne, Australia, is of Vietnamese descent. She's known for her cheerful and energetic personality, love for music and movies, and her adventurous spirit, evident from her willingness to explore new cultures and languages. Favoring Hanni suggests you are open-minded, enthusiastic, and have a zest for life. You likely enjoy exploring new experiences and have a vibrant, outgoing personality.

Danielle (Danielle Marsh/Mo Jihye)

Danielle, born on April 11, 2005, in Newcastle, New South Wales, Australia, is of mixed Korean and Australian heritage. She exudes a bright and optimistic energy, enjoys drawing and painting, and has a natural curiosity about the world. If Danielle is your bias, you might be creative, optimistic, and possess a youthful exuberance. You likely have a passion for the arts and enjoy expressing yourself through various creative outlets.

Haerin (Kang Haerin)

Haerin, born on May 15, 2006, in Seoul, South Korea, is known for her quiet and introspective nature. She enjoys reading and has a deep appreciation for music, often finding solace in these activities. Choosing Haerin as your bias may indicate that you are introspective, thoughtful, and value depth in your pursuits. You likely cherish moments of solitude and have a rich inner world.

Hyein (Lee Hyein)

Hyein, born on April 21, 2008, in Incheon, South Korea, is the youngest member of the group. She has a bright and cheerful personality, loves taking walks and photographing the sky, and has a keen interest in fashion. If Hyein is your bias, you might be youthful at heart, enthusiastic, and have a keen eye for aesthetics. You likely embrace new trends and enjoy capturing the beauty in everyday moments.

Ultimately, your bias in NewJeans reflects the qualities you admire and perhaps see in yourself or aspire to develop.
