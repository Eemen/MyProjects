Hey Tokkies! 💖👋
I’m super excited to share with you all my latest project: a biad identifier I made for a school project! 🎉✨ I really hope you love it as much as I do! 🤞
Stay tuned because there’s definitely more NJZ-related mini-games coming your way! 🎮💥 I can’t wait to share all the cool stuff I’m working on. 💻👾

Just a quick disclaimer 🚨: This website doesn’t generate any money and I don’t have rights to anything NewJeans-related. 🙏💜 It’s all for fun and learning! Enjoy the ride, and thank you so much for checking it out! 😎
