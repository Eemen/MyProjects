{
"questions": [
{
"id": 1,
"question": "You're home alone in the evening. What do you do?",
"options": [
{
"emoji": "📖",
"text": "Read a book and relax",
"points": {
"Haerin": 5,
"Hanni": 4,
"Minji": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎮",
"text": "Play a video game",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🎶",
"text": "Listen to music and sing along",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Hyein": 2,
"Haerin": 1
}
},
{
"emoji": "🖌",
"text": "Do art or drawing",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎬",
"text": "Watch a series or movie",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 2,
"question": "You get to do a leisure activity with NewJeans. What do you choose?",
"options": [
{
"emoji": "🎢",
"text": "Visit an amusement park",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "🎤",
"text": "Sing karaoke",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🏡",
"text": "Cozy evening with board games",
"points": {
"Minji": 5,
"Haerin": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🖼",
"text": "Visit a museum or art gallery",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🛍",
"text": "Go on a shopping spree",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 3,
"question": "Which pet would you like to have the most?",
"options": [
{
"emoji": "🐶",
"text": "A dog",
"points": {
"Danielle": 5,
"Hanni": 4,
"Hyein": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🐱",
"text": "A cat",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🐹",
"text": "A hamster",
"points": {
"Minji": 5,
"Hanni": 4,
"Haerin": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🐢",
"text": "A turtle",
"points": {
"Hyein": 5,
"Haerin": 4,
"Minji": 3,
"Hanni": 2,
"Danielle": 1
}
},
{
"emoji": "🐠",
"text": "Fish in an aquarium",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 4,
"question": "It's a rainy day. What do you do?",
"options": [
{
"emoji": "☕",
"text": "Relax with a book and tea",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎥",
"text": "Have a movie marathon with popcorn",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎮",
"text": "Play video games",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🎶",
"text": "Listen to music and dance",
"points": {
"Hanni": 5,
"Minji": 4,
"Danielle": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎨",
"text": "Paint or craft",
"points": {
"Minji": 5,
"Haerin": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
}
]
},
{
"id": 5,
"question": "You get to choose a city for a trip with NewJeans. Where do you go?",
"options": [
{
"emoji": "🗼",
"text": "Tokyo – Discover modernity and anime",
"points": {
"Hyein": 5,
"Hanni": 4,
"Danielle": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🏖",
"text": "Bali – Beach, sun, and relaxation",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎭",
"text": "Paris – Explore art and fashion",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎤",
"text": "London – Experience the music scene and concerts",
"points": {
"Hanni": 5,
"Minji": 4,
"Danielle": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🏔",
"text": "Seoul – Enjoy culture, shopping, and food",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
}
]
},
{
"id": 6,
"question": "Which song best describes your life?",
"options": [
{
"emoji": "🎶",
"text": "“Attention” – You love being in the spotlight",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Hyein": 2,
"Haerin": 1
}
},
{
"emoji": "🎶",
"text": "“Hype Boy” – You're energetic and passionate",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🎶",
"text": "“Ditto” – You're thoughtful and sentimental",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎶",
"text": "“OMG” – You're creative and a free spirit",
"points": {
"Minji": 5,
"Haerin": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎶",
"text": "“Super Shy” – You're shy but charming",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 7,
"question": "What does your perfect breakfast look like?",
"options": [
{
"emoji": "🥐",
"text": "French breakfast with croissants and coffee",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🍳",
"text": "Hearty breakfast with scrambled eggs and toast",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🍓",
"text": "Smoothie bowl with fresh fruits",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🥞",
"text": "Pancakes with maple syrup and berries",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "🍙",
"text": "Korean breakfast with rice and soup",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
}
]
},
{
"id": 8,
"question": "You can learn a musical instrument. Which one do you choose?",
"options": [
{
"emoji": "🎸",
"text": "Guitar",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎹",
"text": "Piano",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🥁",
"text": "Drums",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🎻",
"text": "Violin",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎤",
"text": "Singing is my instrument!",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 9,
"question": "What is your fashion style?",
"options": [
{
"emoji": "🏙",
"text": "Casual Chic – Classic and elegant",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎨",
"text": "Streetwear – Cool and trendy",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "👗",
"text": "Romantic – Playful with dresses and pastels",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎮",
"text": "Sporty – Comfortable and functional",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "🖤",
"text": "Minimalist – Simple colors, clean cuts",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
}
]
},
{
"id": 10,
"question": "How do you deal with stress?",
"options": [
{
"emoji": "🧘",
"text": "Meditation and relaxation",
"points": {
"Minji": 5,
"Haerin": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎤",
"text": "Sing or listen to music",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎮",
"text": "Play games to clear your mind",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "✍",
"text": "Write in a journal or draw",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🚶",
"text": "Go for a walk or exercise",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 11,
"question": "Which word describes you best?",
"options": [
{
"emoji": "🎵",
"text": "Creative",
"points": {
"Hanni": 5,
"Minji": 4,
"Haerin": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🔥",
"text": "Energetic",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🎭",
"text": "Dreamy",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "📚",
"text": "Thoughtful",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎉",
"text": "Sociable",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 12,
"question": "Your favorite subject in school was …",
"options": [
{
"emoji": "🎨",
"text": "Art",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "📚",
"text": "Literature or languages",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎶",
"text": "Music",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🏃",
"text": "Sports",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "🧪",
"text": "Science",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 13,
"question": "Which superpower would you like to have?",
"options": [
{
"emoji": "🔮",
"text": "See the future",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "⚡",
"text": "Super speed",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🦸",
"text": "Invisibility",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎵",
"text": "Influence people with your voice",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🕊",
"text": "Fly",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 14,
"question": "Which K-pop concept do you like the most?",
"options": [
{
"emoji": "🎀",
"text": "Cute & Girly",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🖤",
"text": "Dark & Mysterious",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎵",
"text": "Retro & Nostalgic",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "💃",
"text": "Powerful & Charismatic",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🚀",
"text": "Futuristic & Unique",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
}
]
},
{
"id": 15,
"question": "What would you do at a NewJeans concert?",
"options": [
{
"emoji": "📸",
"text": "Take photos and videos",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎤",
"text": "Sing along loudly and chant",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "💃",
"text": "Dance and celebrate",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "🥰",
"text": "Enjoy the moment and observe",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎁",
"text": "Prepare a gift for the members",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
},
{
"id": 16,
"question": "Which season suits you best?",
"options": [
{
"emoji": "❄",
"text": "Winter – Calm and thoughtful",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🌸",
"text": "Spring – Creative and full of new energy",
"points": {
"Minji": 5,
"Haerin": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "☀",
"text": "Summer – Cheerful and active",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🍁",
"text": "Autumn – Romantic and nostalgic",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🌟",
"text": "Every season has its charm",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
}
]
},
{
"id": 17,
"question": "What would be your dream job?",
"options": [
{
"emoji": "🎨",
"text": "Artist or designer",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🎤",
"text": "Singer or musician",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎥",
"text": "Filmmaker or actor",
"points": {
"Danielle": 5,
"Minji": 4,
"Hanni": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🚀",
"text": "Scientist or explorer",
"points": {
"Hyein": 5,
"Danielle": 4,
"Minji": 3,
"Hanni": 2,
"Haerin": 1
}
},
{
"emoji": "🏫",
"text": "Teacher or coach",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
}
]
},
{
"id": 18,
"question": "How do you feel about social media?",
"options": [
{
"emoji": "📱",
"text": "I love sharing my experiences",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "📸",
"text": "I post occasionally",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "👀",
"text": "I mostly lurk and rarely comment",
"points": {
"Haerin": 5,
"Minji": 4,
"Hanni": 3,
"Danielle": 2,
"Hyein": 1
}
},
{
"emoji": "🎭",
"text": "I use social media to be creative",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🚫",
"text": "I'm hardly active on social media",
"points": {
"Hyein": 5,
"Minji": 4,
"Haerin": 3,
"Danielle": 2,
"Hanni": 1
}
}
]
},
{
"id": 19,
"question": "Your phone wallpaper is …",
"options": [
{
"emoji": "🎶",
"text": "A photo of my favorite idol",
"points": {
"Hanni": 5,
"Danielle": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
},
{
"emoji": "🎨",
"text": "An aesthetic artwork",
"points": {
"Minji": 5,
"Haerin": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🌿",
"text": "A calming nature scene",
"points": {
"Haerin": 5,
"Minji": 4,
"Danielle": 3,
"Hanni": 2,
"Hyein": 1
}
},
{
"emoji": "🚀",
"text": "Something funny or meme-like",
"points": {
"Hyein": 5,
"Danielle": 4,
"Hanni": 3,
"Minji": 2,
"Haerin": 1
}
},
{
"emoji": "📷",
"text": "A selfie or photo with friends",
"points": {
"Danielle": 5,
"Hanni": 4,
"Minji": 3,
"Haerin": 2,
"Hyein": 1
}
}
]
}
],
"biasDescriptions": {
"Minji": "Minji, born on May 7, 2004, in Chuncheon, Gangwon, South Korea, is often seen as the de facto leader of NewJeans. She has a calm and responsible demeanor, enjoys reading mystery novels, and has a penchant for cleanliness and organization. If Minji is your bias, you might value leadership, responsibility, and have a detail-oriented nature. You likely appreciate a composed and thoughtful approach to challenges and may have a strong sense of duty.",
"Hanni": "Hanni, born on October 6, 2004, in Melbourne, Australia, is of Vietnamese descent. She's known for her cheerful and energetic personality, love for music and movies, and her adventurous spirit, evident from her willingness to explore new cultures and languages. Favoring Hanni suggests you are open-minded, enthusiastic, and have a zest for life. You likely enjoy exploring new experiences and have a vibrant, outgoing personality.",
"Danielle": "Danielle, born on April 11, 2005, in Newcastle, New South Wales, Australia, is of mixed Korean and Australian heritage. She exudes a bright and optimistic energy, enjoys drawing and painting, and has a natural curiosity about the world. If Danielle is your bias, you might be creative, optimistic, and possess a youthful exuberance. You likely have a passion for the arts and enjoy expressing yourself through various creative outlets.",
"Haerin": "Haerin, born on May 15, 2006, in Seoul, South Korea, is known for her quiet and introspective nature. She enjoys reading and has a deep appreciation for music, often finding solace in these activities. Choosing Haerin as your bias may indicate that you are introspective, thoughtful, and value depth in your pursuits. You likely cherish moments of solitude and have a rich inner world.",
"Hyein": "Hyein, born on April 21, 2008, in Incheon, South Korea, is the youngest member of the group. She has a bright and cheerful personality, loves taking walks and photographing the sky, and has a keen interest in fashion. If Hyein is your bias, you might be youthful at heart, enthusiastic, and have a keen eye for aesthetics. You likely embrace new trends and enjoy capturing the beauty in everyday moments."
}
}
